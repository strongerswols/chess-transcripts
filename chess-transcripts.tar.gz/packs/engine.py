import json,os,random,urllib.request as R
NB=60000;MT=100000;IG=1000000;L='abcdefgh'
Q=(0,100,320,330,500,900,0)
ND=(-33,-31,-18,-14,14,18,31,33);BD=(-17,-15,15,17);RD=(-16,-1,1,16);KD=BD+RD
PP='KKKKLMMGLJIKKKKOLLMPMMOQUUUUKKKK'
PN='ACEECGKLELMNEKNOELNOEKMNCGKKACEE'
PB='GIIIILKKIMMMIKMMILLMIKLMIKKKGIII'
PR='KKKLJKKKJKKKJKKKJKKKJKKKLMMMKKKK'
PQ='GIIJIKKKIKLLKKLLJKLLIKLLIKKKGIIJ'
PK='OQMKOOKKIGGGGEECECCAECCAECCAECCA'
PE='AEEEEEKKEIOQEIQSEIQSEIOQEGIKACEG'
PS=(PP,PN,PB,PR,PQ,PK,PE)
def X(t):
 o=[]
 for r in range(8):
  h=[(ord(c)-75)*5 for c in t[r*4:r*4+4]];o+=h+h[::-1]
 return tuple(o)
PS=[X(t) for t in PS]
T=[]
for _ in range(13):T.append([0]*128)
for s in range(128):
 if s&0x88:continue
 i=(s>>4)*8+(s&7)
 for t in range(1,6):
  T[t+6][s]=Q[t]+PS[t-1][i];T[-t+6][s]=-(Q[t]+PS[t-1][i^56])
SQ=[s for s in range(128) if not s&0x88]
_g=random.Random(1)
GR=_g.getrandbits;Z=[[GR(64)for _ in range(128)]for _ in range(12)]
ZS=GR(64);ZC=[GR(64)for _ in range(16)];ZE=[GR(64)for _ in range(8)]
B=[0]*128;S=1;C=0;E=-1;W=4;K=116;H=0;U=[]
D={};N=0;A=False;G=set();V=0;P=0;M=0;Y=0
def I(p):return p-1 if p>0 else 5-p
def SF(f):
 global B,S,C,E,W,K,H,V,P,M,Y
 B=[0]*128
 a=f.split();r=a[0].split('/')
 for n,w in enumerate(r):
  k=7-n;g=0
  for c in w:
   if c.isdigit():g+=int(c)
   else:v='PNBRQK'.find(c.upper())+1;B[k*16+g]=v if c.isupper() else -v;g+=1
 S=1 if a[1]=='w' else -1;C=0
 if len(a)>2:
  for i,c in enumerate('KQkq'):
   if c in a[2]:C|=1<<i
 E=-1
 if len(a)>3 and a[3]!='-':E=(ord(a[3][0])-97)+(int(a[3][1])-1)*16
 W=next(s for s in SQ if B[s]==6);K=next(s for s in SQ if B[s]==-6)
 H=0
 for s in SQ:
  p=B[s]
  if p:H^=Z[I(p)][s]
 if S<0:H^=ZS
 H^=ZC[C]
 if E>=0:H^=ZE[E&7]
 V=P=M=Y=0
 for s in SQ:
  p=B[s]
  if not p:continue
  t=p if p>0 else -p
  if t==6:continue
  V+=T[p+6][s];M+=Q[t]
  if t==1:Y+=1
  else:P+=Q[t]
def MU(m):
 f=m&127;t=(m>>7)&127;p=(m>>14)&7
 s=L[f&7]+str((f>>4)+1)+L[t&7]+str((t>>4)+1)
 if p:s+=' pnbrqk'[p].lower()
 return s
def UM(u):
 a=ord(u[0])-97;b=int(u[1])-1;c=ord(u[2])-97;d=int(u[3])-1
 return a+b*16|((c+d*16)<<7)| ((' pnbrqk'.index(u[4].lower())<<14)if len(u)==5 else 0)
def AT(s,y):
 b=B
 if y>0:
  for t in(s-15,s-17):
   if not t&0x88 and b[t]==1:return True
 else:
  for t in(s+15,s+17):
   if not t&0x88 and b[t]==-1:return True
 for d in ND:
  t=s+d
  if not t&0x88 and b[t]==2*y:return True
 for d in KD:
  t=s+d
  if not t&0x88 and b[t]==6*y:return True
 for d in BD+RD:
  t=s+d
  while not t&0x88:
   p=b[t]
   if p:
    if p==5*y:return True
    e=(t>>4)-(s>>4);f=(t&7)-(s&7)
    if e*e==f*f and p==3*y:return True
    if e*e!=f*f and p==4*y:return True
    break
   t+=d
 return False
def GN(c,o=False):
 b=B;m=[];a=m.append
 for s in SQ:
  p=b[s]
  if p==0 or(p>0)!=(c>0):continue
  t=p if p>0 else -p
  if t==1:
   d=16 if c>0 else -16;g=1 if c>0 else 6;v=7 if c>0 else 0;n=s+d
   if not o:
    if not n&0x88 and b[n]==0:
     if(n>>4)==v:
      for q in(5,2,4,3):a((1000000+Q[q],s|(n<<7)|(q<<14)))
     else:
      a((0,s|(n<<7)))
      if(s>>4)==g:
       w=s+2*d
       if b[w]==0:a((0,s|(w<<7)))
   for k in(d-1,d+1):
    t2=s+k
    if t2&0x88:continue
    q=b[t2]
    if q!=0 and(q>0)!=(c>0):
     z=1000000+10*Q[q if q>0 else -q]-10
     if(t2>>4)==v:
      for q2 in(5,2,4,3):a((z+Q[q2],s|(t2<<7)|(q2<<14)))
     else:a((z,s|(t2<<7)))
    elif t2==E and q==0:a((1000000+90,s|(t2<<7)))
  elif t==2:
   for d in ND:
    t2=s+d
    if t2&0x88:continue
    q=b[t2]
    if q==0:
     if not o:a((0,s|(t2<<7)))
    elif(q>0)!=(c>0):a((1000000+10*Q[q if q>0 else -q]-32,s|(t2<<7)))
  elif t in(3,4,5):
   y=BD if t==3 else RD if t==4 else BD+RD
   for d in y:
    t2=s+d
    while not t2&0x88:
     q=b[t2]
     if q==0:
      if not o:a((0,s|(t2<<7)))
     else:
      if(q>0)!=(c>0):a((1000000+10*Q[q if q>0 else -q]-Q[t]//10,s|(t2<<7)))
      break
     t2+=d
  else:
   for d in KD:
    t2=s+d
    if t2&0x88:continue
    q=b[t2]
    if q==0:
     if not o:a((0,s|(t2<<7)))
    elif(q>0)!=(c>0):a((1000000+10*Q[q if q>0 else -q],s|(t2<<7)))
   if not o:
    if c>0 and s==4:
     if C&1 and b[5]==0 and b[6]==0 and b[7]==4 and not AT(4,-1) and not AT(5,-1) and not AT(6,-1):a((0,4|(6<<7)))
     if C&2 and b[3]==0 and b[2]==0 and b[1]==0 and b[0]==4 and not AT(4,-1) and not AT(3,-1) and not AT(2,-1):a((0,4|(2<<7)))
    elif c<0 and s==116:
     if C&4 and b[117]==0 and b[118]==0 and b[119]==-4 and not AT(116,1) and not AT(117,1) and not AT(118,1):a((0,116|(118<<7)))
     if C&8 and b[115]==0 and b[114]==0 and b[113]==0 and b[112]==-4 and not AT(116,1) and not AT(115,1) and not AT(114,1):a((0,116|(114<<7)))
 return m
def MK(m):
 global S,C,E,W,K,H,V,P,M,Y
 b=B;f=m&127;t=(m>>7)&127;r=(m>>14)&7;p=b[f];c=b[t];q=t
 if(p==1 or p==-1)and t==E and c==0:
  q=t-16 if p>0 else t+16;c=b[q]
 n=(r if p>0 else -r)if r else p
 U.append((m,c,q,C,E,W,K,H,V,P,M,Y))
 if p!=6 and p!=-6:V-=T[p+6][f]
 if c:
  V-=T[c+6][q];x=c if c>0 else -c;M-=Q[x]
  if x==1:Y-=1
  else:P-=Q[x]
 if n!=6 and n!=-6:V+=T[n+6][t]
 if n!=p:
  Y-=1;x=n if n>0 else -n;M+=Q[x]-100;P+=Q[x]
 H^=Z[I(p)][f]
 if c:H^=Z[I(c)][q];b[q]=0
 o=C;g=abs(p)==6
 if g:
  if p>0:C&=~3;W=t
  else:C&=~12;K=t
  if t-f==2:
   v=b[t+1];b[t-1]=v;b[t+1]=0;H^=Z[I(v)][t+1]^Z[I(v)][t-1];V-=T[v+6][t+1];V+=T[v+6][t-1]
  elif f-t==2:
   v=b[t-2];b[t+1]=v;b[t-2]=0;H^=Z[I(v)][t-2]^Z[I(v)][t+1];V-=T[v+6][t-2];V+=T[v+6][t+1]
 for q,m in((0,2),(7,1),(112,8),(119,4)):
  if f==q or t==q:C&=~m
 if o!=C:H^=ZC[o]^ZC[C]
 z=E
 if(p==1 or p==-1)and(t-f==32 or f-t==32):E=(f+t)//2
 else:E=-1
 if z>=0:H^=ZE[z&7]
 if E>=0:H^=ZE[E&7]
 n=(r if p>0 else -r)if r else p
 b[t]=n;b[f]=0;H^=Z[I(n)][t];H^=ZS;S=-S
def UK():
 global S,C,E,W,K,H,V,P,M,Y
 m,c,q,C,E,W,K,H,V,P,M,Y=U.pop()
 f=m&127;t=(m>>7)&127;r=(m>>14)&7;S=-S;p=B[t]
 B[f]=p if not r else(1 if p>0 else -1);B[t]=0
 if p==6 or p==-6:
  if t-f==2:B[t+1]=B[t-1];B[t-1]=0
  elif f-t==2:B[t-2]=B[t+1];B[t+1]=0
 if c:B[q]=c
def EV():
 if M<=330 and Y==0:return 0
 s=V
 k=PS[6] if P<800 else PS[5]
 i=(W>>4)*8+(W&7);s+=k[i]
 i=(K>>4)*8+(K&7);s-=k[i^56]
 return s if S>0 else -s
def QS(a,b,y):
 global N,A
 if A:return 0
 N+=1
 if N>=NB:A=True;return 0
 if H in G:return 0
 c=AT(W if S>0 else K,-S)
 if c:
  p=GN(S);p.sort(reverse=True)
  if not p:return-MT+y
  l=False
  for _,m in p:
   MK(m)
   if AT(W if S<0 else K,S):UK();continue
   l=True;s=-QS(-b,-a,y+1);UK()
   if A:return 0
   if s>a:a=s
   if a>=b:return b
  return-MT+y if not l else a
 s=EV()
 if s>=b:return b
 if s>a:a=s
 p=GN(S,True);p.sort(reverse=True)
 for _,m in p:
  MK(m)
  if AT(W if S<0 else K,S):UK();continue
  s=-QS(-b,-a,y+1);UK()
  if A:return 0
  if s>=b:return b
  if s>a:a=s
 return a
def SC(d,a,b,y,n):
 global N,A
 if A:return 0
 N+=1
 if N>=NB:A=True;return 0
 if y>=128:return EV()
 if H in G:return 0
 c=AT(W if S>0 else K,-S)
 if c:d+=1
 if d<=0:return QS(a,b,y)
 e=D.get(H)
 if e is not None:
  w,f,s2,m=e
  if w>=d:
   if f==0:return s2
   if f==1 and s2>=b:return b
   if f==2 and s2<=a:return a
 p=GN(S);p.sort(reverse=True)
 if not p:return-MT+y if c else 0
 g=-IG;v=0;f=2;x=a
 for _,m in p:
  MK(m)
  if AT(W if S<0 else K,S):UK();continue
  s=-SC(d-1,-b,-x,y+1,True);UK()
  if A:return 0
  if s>g:g=s;v=m
  if s>x:x=s
  if x>=b:
   f=1;break
 if g==-IG:return-MT+y if c else 0
 if g>a:f=0 if g<b else 1
 if len(D)>500000:D.clear()
 D[H]=(d,f,g,v)
 return g
def SR(u,md=40):
 global N,A
 r=[UM(x) for x in u];b=r[0]
 N=0
 for d in range(1,md+1):
  A=False;z=None;g=-IG;a=-IG
  for m in r:
   MK(m);s=-SC(d-1,-IG,-a,1,True);UK()
   if A:break
   if s>g:g=s;z=m
   if s>a:a=s
  if A or z is None:break
  b=z
  if g>MT-1000:break
 return MU(b)
EL=os.environ.get("MAKEFUN_ENV_URL")
def PO(p,b):
 q=R.Request(EL+p,data=json.dumps(b).encode())
 with R.urlopen(q) as r:return json.load(r)
def BH(m):
 global G
 SF("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1")
 U.clear();G=set()
 for u in m:
  G.add(H);MK(UM(u))
 G.add(H);U.clear()
def main():
 while True:
  g=PO("/game",{})
  if g["status"]=="done":break
  while g["status"]=="your_move":
   BH(g.get("moves",[]));SF(g["fen"]);m=SR(g["legal_moves"]);g=PO("/move",{"game":g["game"],"move":m})
main()
